var express = require('express');
var router = express.Router();
var request =  require("request");
var prompt = require ('prompt')
/* GET home page. */
router.get('/', function(req, res, body) {
 // res.json({message:'My first API'});
//});
prompt.start();


var add = "";
var key = "AIzaSyBdWk4MVPO-U5egM4w42SHSEACwBpxrqgA";
var url = "https://maps.googleapis.com/maps/api/geocode/json?address=";
//var add = "1600 Amphitheatre Parkway, Mountain View, CA";
var fullUrl = "";
console.log("starting")
 prompt.get(['streetname', 'city','state'], function (err, result) {
    if (err) { return onErr(err); }
    console.log('Command-line input received:');
    console.log('  streetname: ' + result.streetname);
    console.log('  city: ' + result.city);
    console.log('  state(abr): ' + result.state);

    function onErr(err) {
    console.log(err);
  
  }

    add =  result.streetname +"," + result.city + "," + result.state;
    fullUrl = url + add + "&key" +key;

request(fullUrl, function (error, response, body) {
	if (!error && response.statusCode == 200) {
		res.send(body);
	}
	else {
		console.log("unable to pull address")
	}
});
});




 

  });



module.exports = router;
