var express = require('express');
var router = express.Router();
var request =  require("request");
/* GET home page. */
router.get('/', function(req, res, body) {
 // res.json({message:'My first API'});
//});

var key = "AIzaSyActCovHj7yjGXJoeW2e3Pu1mly-qPiIbI";
var url = "https://maps.googleapis.com/maps/api/timezone/json?location=";
var lat = "39.6034810";
var lng = "-119.6822510";
var timestamp = "1331161200"


var fullUrl = url + lat + "," +lng + "&timestamp=" + timestamp+ "&key=" + key  ;

request(fullUrl, function (error, response, body) {
	if (!error && response.statusCode == 200) {
		res.send(body);
	}
	else {
		console.log("unable to pull timestamp")
	}
});
});



module.exports = router;
